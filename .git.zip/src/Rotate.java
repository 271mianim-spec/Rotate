public class Rotate {
    static int[][] grid = {{1,2,3},{4,5,6},{7,8,9}};

    public static void main(String[] args) {
        System.out.println(printGrid);
    }

    public String printGrid(int[][] printGrid) {
        String gridString = "";
        for (int row = 0; row < grid.length; row++) {
            for (int col = 0; col < grid[row].length; col++) {
                gridString += grid[row][col];
            }
            gridString = "\n" + gridString;
        }
        return gridString;
    }
}
